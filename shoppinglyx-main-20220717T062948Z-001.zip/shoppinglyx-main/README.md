# shoppinglyx
This is a Static DJango Shopping Website 
![alt text](https://github.com/geekyshow1/shoppinglyx/blob/main/Screenshots/Home.jpeg)
